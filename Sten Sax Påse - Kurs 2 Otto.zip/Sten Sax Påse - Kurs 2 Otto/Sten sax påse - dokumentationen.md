Sten, sax, påse – Projektet

Av Otto Arvidsson

-   13 December

Jag har idag påbörjat projektet med att ha ritat en skiss och ha påbörjat koda projektet i Visual Studio Code.

Jag har huvudsakligen blivit klar med html filen och har lagt upp alla min taggar i ordning.

Jag har huvudsakligen blivit klar med CSS filen, har ritat upp allt i en header och gjort en hel body-main som spelet tar plats inom.

Jag har huvudsakligen blivit klar med JavaScript filen med spelets huvudsakliga funktioner, man kan välja alla alternativen och spela helt utan avbrott,

-   14 December

Commit, har nu lagt till att man kan har en knapp som visar reglerna av spelet för användaren.

Commit, har nu även lagt till så man kan välja/ändra sitt spelare-namn i programmet.

-   16 December

Har försökt göra nya ändringar, men verkar nästan göra mer skada än nytta för projektet.
