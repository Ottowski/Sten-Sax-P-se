let userScore = 0;
let computerScore = 0;
let userScore_span = document.getElementById("user-score");
let computerScore_span = document.getElementById("computer-score");
let score_div = document.querySelector(".score");
let result_div = document.querySelector(".result > p");
let sten_div = document.getElementById("sten");
let sax_div = document.getElementById("sax");
let påse_div = document.getElementById("påse");
let username = document.getElementById("user-label");
let messageShown = false;

function getComputerChoice() {
    let choices = ["sten", "sax", "påse"];
    let randomNumber = (Math.floor(Math.random() * 3));
    return choices[randomNumber];
}
function game(userChoice) {
    let computerChoice = getComputerChoice();
    switch (userChoice + computerChoice) {
        case "stensax":
        case "saxpåse":
        case "påsesten":
            //console.log("DU VINNER!")
            win(userChoice, computerChoice);
            break;
        case "stenpåse":
        case "påsesax":
        case "saxsten":
            //console.log("DATORN VINNER!")
            lose(userChoice, computerChoice);
            break;
        case "stensten":
        case "saxsax":
        case "påsepåse":
            //console.log("INGEN VINNER!")
            draw(userChoice, computerChoice);
            break;
    }
}

function main() {
    sten_div.addEventListener("click", function () {
        game("sten")
        //console.log("Du har klickat på sten");
    })
    sax_div.addEventListener("click", function () {
        game("sax")
        //console.log("Du har klickat på sax");
    })
    påse_div.addEventListener("click", function () {
        game("påse")
        //console.log("Du har klickat på påse");
    })
}
function win(userChoice, computerChoice) {
    userScore++;
    userScore_span.innerHTML = userScore;
    computerScore_span.innerHTML = computerScore;
    result_div.innerHTML = userChoice + " slår " + computerChoice + ". Du vann!";
}
function lose(userChoice, computerChoice) {
    computerScore++;
    userScore_span.innerHTML = userScore;
    computerScore_span.innerHTML = computerScore;
    result_div.innerHTML = userChoice + " förlorar mot " + computerChoice + ". Du förlorade!";
}

function draw(userChoice, computerChoice) {
    result_div.innerHTML = userChoice + " mot " + computerChoice + " är lika. ingen vann!";

}
username.addEventListener("click", () => {
    const name = prompt('Skriv in ett nytt namn');
    username.textContent = `${name}`;
});

document.querySelector('.button-rules').addEventListener('click', function (e) {
    // Toggle the display of the message
    messageShown = !messageShown;
    if (messageShown === true) {
        document.getElementById('Message').style.display = 'block';
    } else {
        document.getElementById('Message').style.display = 'none';
    }
})

button.addEventListener("click", () => {

    if (button.innerText === "Reglerna") {
        button.innerText = "Tillbaka";
    } else {
        button.innerText = "Reglerna";
    }
});

main();